rm(list=ls())  
folder <- "/Users/sunjiajing/Desktop/UoB-research-teaching2023/Teaching2023-24/DPS/R-handout-DPS/R-DPS/CH3" 
setwd(folder) # setting working folder

################################################################### 

mdeaths <- read.csv ("mdeaths.csv") #loading dataset 
head(mdeaths)   
str(mdeaths)


# Visualization of the data in R using a blue line graph
plot(mdeaths$x, type="l", col="blue") 

# Convert mdeaths$x into a time series starting from January 1974
mdeaths_ts <- ts(mdeaths$x, start=c(1974, 1), frequency=12)

# Plot the mdeaths time series with specified attributes
plot(mdeaths_ts,  col="blue", xlab="Time",  main="Monthly deaths between 1974–1980")

################################################################### 
#  More complex plots: 

# Histogram:
hist(mtcars$mpg, main="Histogram of Miles-per-Gallon", 
     xlab="MPG", col="lightblue", border="red")

# Scatter plots:
plot(mtcars$wt, mtcars$mpg, main="Weight vs. MPG", 
     xlab="Weight", ylab="MPG", pch=20, col="red")

# Box plots:
boxplot(mpg ~ am, data=mtcars, main="MPG by Transmission Type", 
        xlab="Transmission (0=Automatic, 1=Manual)", ylab="MPG", 
        col=c("lightblue","lightgreen"))

# Pair plots (scatterplot matrix):
pairs(~mpg+hp+wt+qsec, data=mtcars, main="Scatterplot Matrix of mtcars")

# Correlation heatmap:
library(corrplot)
correlations <- cor(mtcars)
corrplot(correlations, method="circle")

# 3D scatter plots:
library(scatterplot3d)
scatterplot3d(mtcars$hp, mtcars$wt, mtcars$mpg, 
              xlab="Horsepower", ylab="Weight", zlab="Miles per Gallon",
              pch=20, color="red", main="3D Scatterplot: HP vs. Weight vs. MPG")




