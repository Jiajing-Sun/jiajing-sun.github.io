rm(list=ls())  
library(ggplot2)

# Data layer
ggplot(data = mtcars) +
  labs(title = "Visualization of mtcars Dataset")

# Aesthetic layer 
ggplot(data = mtcars, aes(x = hp, y = mpg, col = disp))+
  labs(title = "Automobile Data: Displacement and Efficiency",
       x = "Engine Power (HP)",
       y = "Efficiency (MPG)")

# Geometric layer
ggplot(data = mtcars, aes(x = hp, y = mpg, col = disp)) +
  geom_point() +
  labs(title = "Horsepower versus Fuel Efficiency",
       x = "Engine Power (HP)",
       y = "Efficiency (MPG)") 

# Incorporating size
ggplot(data = mtcars, aes(x = hp, y = mpg, size = disp)) +
  geom_point() +
  labs(title = "Engine Power vs Fuel Efficiency",
       x = "Engine Power (HP)",
       y = "Efficiency (MPG)")

# Employing shape and color
ggplot(data = mtcars, aes(x = hp, y = mpg, col = factor(cyl), 
                          shape = factor(am))) +
  geom_point() +
  labs(title = "Automobile Efficiency by Cylinder Count and Transmission",
       x = "Engine Power (HP)",
       y = "Efficiency (MPG)")

# Constructing a histogram
ggplot(data = mtcars, aes(x = hp)) +
  geom_histogram(binwidth = 30, fill = "red", color = "green") +
  labs(title = "Distribution of Horsepower",
       x = "Engine Power (HP)",
       y = "Frequency")

# Segregating by transmission type
p <- ggplot(data = mtcars, aes(x = hp, y = mpg)) + geom_point()
p + facet_grid(am ~ .) +
  labs(title = "Fuel Efficiency vs Engine Power by Transmission Style",
       x = "Engine Power (HP)",
       y = "Efficiency (MPG)")

# Segmenting by number of cylinders
p + facet_grid(. ~ cyl) +
  labs(title = "Fuel Efficiency vs Engine Power by Cylinder Count",
       x = "Engine Power (HP)",
       y = "Efficiency (MPG)")

# Histogram
ggplot(mtcars, aes(x = mpg)) +
  geom_histogram(binwidth = 1, fill = "lightblue", color = "blue") +
  labs(title = "Histogram of Miles Per Gallon", x = "Efficiency (MPG)", y="Count")

# Boxplot
ggplot(mtcars, aes(x = factor(cyl), y = mpg)) +
  geom_boxplot(fill = "lightblue", color = "blue") +
  labs(title = "Boxplot of Miles Per Gallon by Cylinder Count")

# Bar Plot
ggplot(mtcars, aes(x = factor(cyl))) +
  geom_bar(fill = "green", color = "black") +
  labs(title = "Bar Plot of Car Counts by Cylinder")

# Pie Chart (Using Bar Plot and coord_polar)
ggplot(mtcars, aes(x = factor(1), fill = factor(cyl))) +
  geom_bar(width = 1) +
  coord_polar(theta = "y") +
  labs(title = "Pie Chart of Cylinder Counts")

# Density Plot
ggplot(mtcars, aes(x = mpg)) +
  geom_density(fill = "magenta") +
  labs(title = "Density Plot of Miles Per Gallon")

# QQ-Plot
ggplot(mtcars, aes(sample = mpg)) +
  stat_qq() +
  stat_qq_line() +
  labs(title = "QQ-Plot of Miles Per Gallon")

# Contour plot with 2D density 
ggplot(mtcars, aes(x = wt, y = mpg)) +
  stat_density_2d(aes(fill = after_stat(level)), geom = "polygon", color = "white") + 

  labs(title = "2D Density Contour Plot of mtcars Dataset",
       x = "Weight (wt)",
       y = "Miles Per Gallon (mpg)",
       fill = "Density")

# Saving and extracting the plots
plot <- ggplot(data = mtcars, aes(x = hp, y = mpg)) + geom_point()
ggsave("engine_power_vs_efficiency.png", plot)
# Isolating the plot as a variable for subsequent utilization
extracted_plot <- plot
extracted_plot 
