 rm(list=ls()) 
set.seed(123456789 )  

# for loop 

for (i in 1:5) {
  print(i)
}

# while loop 

i <- 0
while (i <= 5) { 
  i <- i + 1
  print(i)
}

# repeat loop 
i <- 0
repeat {
  i <- i + 1
  if (i > 5) {
    break
  }
  print(i)
}

# lapply 
lapply(0:4, function(a) {a + 1})

add_fun <- function(a) {a + 1}
lapply(0:4, add_fun)

sapply(0:4, function(a) {a + 1})