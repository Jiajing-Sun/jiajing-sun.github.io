 rm(list=ls()) 
set.seed(123456789 ) 
################################################################### 
# CDF of a standard normal distribution
compute_phi <- function(z) {
  integrand <- function(t) {
    (1/sqrt(2 * pi)) * exp(-t^2 / 2)
  }
  result <- integrate(integrand, -Inf, z)
  return(result$value)
}
 
# Test the function
z_val <- 1.96
print(compute_phi(z_val))

# Compare with built-in function
print(pnorm(z_val)) 

################################################################### 
# Use the inverse CDF method.  

# First, sample from the continous uniform distribution on [0,1]
sample.unif <- runif(1000)    

# The inverse of CDF for the stanard normal distribution is 
inverse_phi <- function(phi_value) {
  function_to_zero <- function(z) {
    compute_phi(z) - phi_value
  }
  root <- uniroot(function_to_zero, c(-10, 10)) # Here, c(-10, 10) is a range where you expect to find the value of z. Adjust if needed.
  return(root$root)
}

# Sample from the standard normal distribution 
sample.norm<- as.numeric (lapply(sample.unif, inverse_phi))  

# Plot histogram
hist(sample.norm, probability = TRUE, main = "Histogram with Density Curve", xlab = "Value", col = "lightblue", border = "black")

# Overlay empirical density curve
lines(density(sample.norm), col = "red", lwd = 2). 

# Examine the statistical properties of the generated data 
mean(sample.norm)
var(sample.norm)

library(tseries)
skewness(sample.norm)
kurtosis(sample.norm)

