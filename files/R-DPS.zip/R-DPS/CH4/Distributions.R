# If you haven't installed the purrr package, you need to install it.
#install.packages("purrr") 

set.seed(1234) # Setting the random seed.
library(purrr) # Loading the purrr library.

# Generating discrete uniformly distributed random variables.
rdunif(10, b=50, a=10)
rdunif(10, 100)
rdunif(10, 10, -10)
table(rdunif(20, 3, -3))

# Generating continuous uniformly distributed random variables.
runif(10, min=1, max=3)

# Generating 100 standard normally distributed random variables.
rnorm(100)

# Generating 100 normally distributed random variables with mean 1 and standard deviation 5.
rnorm(100, 1, 5)


# Probability density fucntions of various normal distributions: 

# Load the ggplot2 package
library(ggplot2)

# Create a data frame to plot different normal distributions
x <- seq(-10, 10, by = 0.01)
df <- data.frame(
  x = x,
  y0.2 = dnorm(x, mean=0, sd=sqrt(0.2)),
  y1 = dnorm(x, mean=0, sd=sqrt(1)),
  y5 = dnorm(x, mean=0, sd=sqrt(5)),
  y0.5 = dnorm(x, mean=0, sd=sqrt(0.5))
)

# Plot using ggplot2 with a minimal theme
p <- ggplot(df, aes(x = x)) + 
  geom_line(aes(y = y0.2, color = "σ^2 = 0.2")) + 
  geom_line(aes(y = y1, color = "σ^2 = 1")) +
  geom_line(aes(y = y5, color = "σ^2 = 5")) +
  geom_line(aes(y = y0.5, color = "σ^2 = 0.5")) +
  labs(title = "Probability Density Functions of Normal 
Distributions with Different Variances",
       x = "x",
       y = "Density",
       color = "Variance") + 
  theme_minimal()

# Display the plot
print(p)

# Adjust the plot to use a black & white theme
p <- ggplot(df, aes(x = x)) + 
  geom_line(aes(y = y0.2, color = "σ^2 = 0.2")) + 
  geom_line(aes(y = y1, color = "σ^2 = 1")) +
  geom_line(aes(y = y5, color = "σ^2 = 5")) +
  geom_line(aes(y = y0.5, color = "σ^2 = 0.5")) +
  labs(title = "Probability Density Functions of Normal 
Distributions with Different Variances",
       x = "x",
       y = "Density",
       color = "Variance") + 
  theme_bw()

# Save the plot as a PNG file
ggsave(filename = "normal_distributions.png", plot = p, 
       width = 10, height = 6, dpi = 300)
