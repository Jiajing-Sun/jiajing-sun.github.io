# Approximating e, Euler's constant

# First, using compound interest rate
e.fcn.1 <-function(n=2000){
  (1+1/n)^n} 

e.fcn.1(1) 
e.fcn.1(100)
e.fcn.1(10000)  # As n increases, we get a closer approximation to \(e\)

exp(1) # This returns the value of Euler's constant, e

# Second, approximating \(e\) using the sum of an infinite series 
e.fcn.2 <- function(n=2000){ 
  e <- 0 
  for (i in 0: n ){
    e <- e + 1/factorial(i)  } 
  return (e)
}
e.fcn.2(1)
e.fcn.2(10)

# Third, a more concise version of the second method
e.fcn.3 <- function(n=2000){
  e<- sum(1/factorial(0:n)) 
  return (e)} 
e.fcn.3(1)
e.fcn.3(10) 

