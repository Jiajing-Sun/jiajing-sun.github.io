rm(list=ls())  
folder <- "/Users/sunjiajing/Desktop/UoB-research-teaching2023/Teaching2023-24/DPS/R-handout-DPS/R-DPS/CH2" 
setwd(folder) # setting working folder

################################################################### 

mdeaths <- read.csv ("mdeaths.csv") #loading dataset 
head(mdeaths)   
str(mdeaths)
################################################################### 

# calculate the mean and variance of the dataset 
avg_mdeaths<- mean(mdeaths$x)
var_mdeaths<- var(mdeaths$x)
avg_mdeaths
var_mdeaths
sd_mdeaths <- sqrt(var_mdeaths) # the standard deviation is simply the square root of the variance
sd_mdeaths 
################################################################### 

# Basic data manipulation 
# Example: Selecting the 2nd to 4th elements
subset_mdeaths <-mdeaths$x [2:4]

# Example: Filtering elements where the the number of death is above 1500
filtered_mdeaths <- mdeaths$x [mdeaths$x > 1500 ]

# Visualization of the data in R using a blue line graph
plot(mdeaths$x, type="l", col="blue") 

# Convert mdeaths$x into a time series starting from January 1974
mdeaths_ts <- ts(mdeaths$x, start=c(1974, 1), frequency=12)

# Plot the mdeaths time series with specified attributes
plot(mdeaths_ts,  col="blue", xlab="Time",  main="Monthly deaths between 1974–1979")

################################################################### 
# aggregating 
# use R base command: 
# Calculate average MPG for each group of cylinders
avg_mpg_by_cyl <- aggregate(mpg ~ cyl, data = mtcars, FUN = mean)
# Display the result
print(avg_mpg_by_cyl)

# use dplyer package: 
# Load the necessary library
library(dplyr)

# Compute the aggregation
avg_mpg_by_cyl <- mtcars %>%
  group_by(cyl) %>%
  summarise(avg_mpg = mean(mpg))

# Display the result
print(avg_mpg_by_cyl)

################################################################### 
#  More complex plots: 

# Histogram:
hist(mtcars$mpg, main="Histogram of Miles-per-Gallon", 
     xlab="MPG", col="lightblue", border="red")

# Scatter plots:
plot(mtcars$wt, mtcars$mpg, main="Weight vs. MPG", 
     xlab="Weight", ylab="MPG", pch=20, col="red")

# Box plots:
boxplot(mpg ~ am, data=mtcars, main="MPG by Transmission Type", 
        xlab="Transmission (0=Automatic, 1=Manual)", ylab="MPG", 
        col=c("lightblue","lightgreen"))

# Pair plots (scatterplot matrix):
pairs(~mpg+hp+wt+qsec, data=mtcars, main="Scatterplot Matrix of mtcars")
 
# Correlation heatmap:
library(corrplot)
correlations <- cor(mtcars)
corrplot(correlations, method="circle")

# 3D scatter plots:
library(scatterplot3d)
scatterplot3d(mtcars$hp, mtcars$wt, mtcars$mpg, 
              xlab="Horsepower", ylab="Weight", zlab="Miles per Gallon",
              pch=20, color="red", main="3D Scatterplot: HP vs. Weight vs. MPG")


 
 
