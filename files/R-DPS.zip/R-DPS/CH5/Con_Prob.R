
rm(list=ls()) 

################################################################### 
# Estimating pi using Monte Carlo Simulation
set.seed(1234567)  # Setting a seed for reproducibility

n_points <- 10000  # Number of random points

# Generate random points in the square [-1, 1] x [-1, 1]
x <- runif(n_points, min=-1, max=1)
y <- runif(n_points, min=-1, max=1)

# Determine how many points fall inside the circle of radius 1
inside_circle <- sum(x^2 + y^2 <= 1)

# Estimate pi
pi_estimate <- 4 * inside_circle / n_points

print(pi_estimate)
 
################################################################### 
# Simulate 1000 rolls of a dice

rolls <- sample(1:6, 10000000, replace=TRUE)

# P(A): Probability that the roll is even
P_A <- mean(rolls %% 2 == 0)

# P(B): Probability that the roll is greater than 3
P_B <- mean(rolls > 3)

# P(A|B): Probability that the roll is even given it's greater than 3
P_A_given_B <- mean(rolls[rolls > 3] %% 2 == 0)
P_A_given_B 
################################################################### 

# P(A and B): Probability that roll is even and greater than 3
P_A_and_B <- mean(rolls > 3 & rolls %% 2 == 0)

# Compute P(A|B) using the formula
P_A_given_B_formula <- P_A_and_B / P_B
P_A_given_B_formula

################################################################### 

# Consider two dice rolls: A is the event both dice sum to 7.
# B1 is the event the first dice is 1, B2 is 2, etc.
dice <- expand.grid(1:6, 1:6)
P_A_given_B <- numeric(6)
P_B <- 1/6

for(i in 1:6) {
  P_A_given_B[i] <- mean(dice$Var1 + dice$Var2 == 7 & dice$Var1 == i)
}

# Law of total probability
P_A <- sum(P_A_given_B * P_B)

# Assuming we know event A occurred, Bayes' formula to find probability the first dice was a 2:
P_B2_given_A <- (P_A_given_B[2] * P_B) / P_A
P_B2_given_A 
################################################################### 
# With dice rolls, the roll of one dice doesn't 
# affect the other, so they're independent

# P(A): Probability that the roll is even
P_A <- mean(rolls %% 2 == 0)

# P(B): Probability that the roll is greater than 3
P_B <- mean(rolls > 3)

# P(A and B): Probability that roll is even and greater than 3
P_A_and_B <- mean(rolls > 3 & rolls %% 2 == 0)

tolerance <- 1e-1
independent <- abs(P_A_and_B - (P_A * P_B)) < tolerance
independent
################################################################### 
# Joint probability of rolling a 3 on the first dice and a 4 on the second dice
P_roll3 <- mean(dice$Var1 == 3)
P_roll4 <- mean(dice$Var2 == 4)

joint_prob <- P_roll3 * P_roll4
joint_prob 