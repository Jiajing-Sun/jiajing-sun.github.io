
rm(list=ls()) 

#set.seed(1234567) 


################################################################### 
# Demonstration of the law of large number using coin flips: 
flips <- sample(c(0, 1), 1000, replace = TRUE)
cum_avg <- cumsum(flips) / (1:1000)
plot(cum_avg, type = "l", ylim = c(0, 1), ylab = "Cumulative Average", xlab = "Number of Flips")
abline(h=0.5, col="red")
 


################################################################### 
# We demonstrate the validity of De Moivre-Laplace Theorem:
n <- 1000
p <- 0.5
binom_samples <- rbinom(10000, size=n, prob=p)
normalized_samples <- (binom_samples - n*p) / sqrt(n*p*(1-p))
hist(normalized_samples, breaks=50, prob=TRUE, main="De Moivre-Laplace Demonstration", xlab="Value")
curve(dnorm(x), add=TRUE, col="red") 


################################################################### 
# Monte Carlo Simulation of the Central Limit Theorem - Using Dice Rolls

# Number of dice
n_dice <- 10

# Number of rolls
n_rolls <- 10000

# Simulation
simulated_sums <- replicate(n_rolls, sum(sample(1:6, n_dice, replace=TRUE)))

# Normalize the sums to get sample means
simulated_means <- simulated_sums / n_dice

# Plot the histogram of the sample means
hist(simulated_means, breaks=50, probability=TRUE,
     main="Demonstration of Central Limit Theorem",
     xlab="Sample Mean of Dice Rolls", 
     ylab="Density", 
     col="lightblue", border="black")

# Add a density curve of a normal distribution for comparison
x_vals <- seq(1, 6, length=100)
norm_density <- dnorm(x_vals, mean=3.5, sd=sqrt(35/12)/sqrt(n_dice))
lines(x_vals, norm_density, col="red", lwd=2)

legend("topright", legend=c("Simulated Data", "Normal Distribution"), 
       lty=c(1,1), col=c("black", "red"))

################################################################### 
# Markov's Inequality  

samples <- abs(rnorm(1000))
a <- 3
empirical_prob <- mean(samples >= a)
markov_bound <- mean(samples) / a
empirical_prob <= markov_bound  


# Chebyshev's Inequality
samples <- rnorm(1000, mean=5, sd=2)
k <- 2
empirical_prob <- mean(abs(samples - mean(samples)) >= k*sd(samples))
chebyshev_bound <- 1 / (k^2)
empirical_prob <= chebyshev_bound
